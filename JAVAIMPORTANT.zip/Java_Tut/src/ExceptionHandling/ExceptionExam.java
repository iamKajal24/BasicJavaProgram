package ExceptionHandling;

public class ExceptionExam {
    public static void main(String[] args) {
        System.out.println("Program Started");

        try {
            int n1 = 45;
            int n2 = 4;
            System.out.println("We have two numbers: " + n1 + " and " + n2);
            
            int result = n1 / n2;
            System.out.println("Division result: " + result);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter valid numbers.");
        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by zero.");
        }

        System.out.println("Program Terminated");
    }
}
