package ExceptionHandling;

import java.util.Scanner;

class MyException extends Exception{
	public String toString() {
		return "I am toString";
		
	}
	public String getMessage() {
		return " I am getMessage";
		
	}
}
public class Throw {
	public static void main(String[] args) {
		int a;
		Scanner scanner=new Scanner(System.in);
		a=scanner.nextInt();
		if(a<99) {
			try {
			throw new MyException();
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
				System.out.println(e.toString());
				System.out.println(e);
			}
		}
	}

}
