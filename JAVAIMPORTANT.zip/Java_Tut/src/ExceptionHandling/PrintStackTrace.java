package ExceptionHandling;

public class PrintStackTrace {
	public static void main(String[] args) {
		int a = 78;
		int b = 0;
		try {
			int result = a / b;
			System.out.println("Divison is " + result);
		} catch (ArithmeticException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			;
		}
	}
}
