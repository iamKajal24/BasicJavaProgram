package FileHandling1;

import java.io.File;
import java.io.IOException;

public class Test {
	public static void main(String[] args) {
		String path = "C:/Users/Kajal/Desktop/FileHandlingExample/abc.txt";
		File file = new File("path");
		
		try {
			if(file.createNewFile()) {
				System.out.println("File created successfully");
			}
			else {
				System.out.println("File already available");
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
