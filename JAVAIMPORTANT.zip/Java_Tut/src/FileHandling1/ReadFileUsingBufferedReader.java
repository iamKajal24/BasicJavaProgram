package FileHandling1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadFileUsingBufferedReader {
	public static void main(String[] args) {
		String path = "/Users/Kajal/Desktop/FileHandlingExam/kajalPandit.txt";
		BufferedReader bReader = null;
		try {
			File file = new File(path);
			bReader = new BufferedReader(new FileReader(file));

			System.out.println("File content is:");
			int c;
			// Corrected loop for reading characters from the BufferedReader
			while ((c = bReader.read()) != -1) {
				System.out.print((char) c);
			}

		} catch (IOException e) {
			// Properly catching and handling IOExceptions
			e.printStackTrace();
		} finally {
			// Closing the BufferedReader in the finally block to ensure it gets closed even
			// if an exception occurs
			if (bReader != null) {
				try {
					bReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
