package FileHandling1;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class OpenFileUsingDesktop {
    public static void main(String[] args) {
        String path = "C:/Users/Kajal/Desktop/FileHandlingExam/kajalPandit.txt";
        File file = new File(path);

        // Check if Desktop is supported on the current platform
        if (!Desktop.isDesktopSupported()) {
            System.out.println("Desktop operations are not supported on your system.");
            return;
        }

        Desktop desktop = Desktop.getDesktop();

        try {
            // Check if the file exists before attempting to open it
            if (file.exists()) {
                desktop.open(file);
                System.out.println("File opened successfully.");
            } else {
                System.out.println("File does not exist at the specified path: " + path);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while trying to open the file.");
            e.printStackTrace();
        }
    }
}
