package FileHandling1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * FileHandling 1.
 * Copy a file (pdf) and create a different file in the same location
 * @param arg
 */
public class CopyFile {
	public static void main(String[] args) {
		copyFile();
	}

	public static void copyFile() {
		File file = new File("C:/Users/Kajal/Desktop/Java_Complete_Notes.pdf");
		File Opfile = new File("C:/Users/Kajal/Desktop/Java_Complete_Notes-Copy.pdf");

		FileInputStream fileInputStream = null;
		FileOutputStream fileOutputStream = null;

		try {
			fileInputStream = new FileInputStream(file);
			fileOutputStream = new FileOutputStream(Opfile); // opfile = copy file

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		try {
			System.out.println(fileInputStream.available());
		} catch (IOException e) {

			e.printStackTrace();
		}

		int i = 0;
		try {
			while ((i = fileInputStream.read()) != -1) {
				fileOutputStream.write(i);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		finally {
			// close the stream :
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
			if (fileOutputStream != null) {
				try {
					fileOutputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
}
