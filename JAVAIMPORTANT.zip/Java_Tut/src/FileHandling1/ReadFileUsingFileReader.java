package FileHandling1;

import java.io.FileReader;

public class ReadFileUsingFileReader {
	public static void main(String[] args) {
		String path = "/Users/Kajal/Desktop/FileHandlingExam/kajalPandit.txt";
		FileReader fReader = null;
		try {
			fReader = new FileReader(path);
			System.out.println("file content is ");

			int c = 0;
			while ((c = fReader.read()) != -1) {
				System.out.println((char) c);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		finally {
			try {
				fReader.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}

	}

}
