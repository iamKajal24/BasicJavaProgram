package FileHandling1;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class CreateFile {
	public static void main(String[] args) throws IOException {

		// 1. windows : c:\\users\\kajal\\FileHandle\\sample.text
		String path = "C:/Users/Kajal/Desktop/FileHandlingExam/sample.txt";

		File file = new File(path);
		boolean flag = file.createNewFile();
		if (flag) {
			System.out.println("File is successfully created");
		} else {
			System.out.println("File is already Available");

		}

//*************************************************************************

		/*
		 * 2. FileOutStream Along with Scanner
		 * 
		 */

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the file name with Location path");
		String fileName = scanner.nextLine();

		FileOutputStream fileOutputStream = new FileOutputStream(fileName, true);
		System.out.println("Enter the file Content");
		String content = scanner.nextLine();
		byte b[] = content.getBytes();

		fileOutputStream.write(b);
		fileOutputStream.close();
		System.out.println("File is saved on the given location path : ");

		/*Output:
		 * 
		 * Enter the file name with Location path
		 * C:/Users/Kajal/Desktop/FileHandlingExam/kajal.txt Enter the file Content This
		 * is kajalAutomation with File Handling Codee Practice File is saved on the
		 * given location path :
		 */

		// 3. Java nio package
		
		Path pathLocation=Paths.get("C:/Users/Kajal/Desktop/FileHandlingExam/newFile.text");
	    Path newPath =	Files.createFile(pathLocation);
	    System.out.println("new file created at : " + newPath);
	}
}
