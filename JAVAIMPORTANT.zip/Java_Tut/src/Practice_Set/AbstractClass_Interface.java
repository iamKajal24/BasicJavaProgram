package Practice_Set;

abstract class Pen {
	abstract void write();

	abstract void refill();

}

class fountainPen extends Pen {

	@Override
	void write() {
		System.out.println("Write");
	}

	@Override
	void refill() {
		System.out.println("Refill");

	}

	void ChangeNib() {
		System.out.println("Changing Nib");
	}

}

public class AbstractClass_Interface {
	public static void main(String[] args) {
		fountainPen obj = new fountainPen();
		obj.write();
		obj.refill();
		obj.ChangeNib();
	}

}
