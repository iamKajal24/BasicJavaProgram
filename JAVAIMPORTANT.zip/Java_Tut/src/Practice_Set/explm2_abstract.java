package Practice_Set;

class Monkey {
	void jump() {
		System.out.println("Jumping");
	}

	void Bite() {
		System.out.println("Bite ");
	}
}

interface BasicAnumal {
	void eat();

	void sleep();
}

class Human extends Monkey implements BasicAnumal {
	void speek() {
		System.out.println("Hello Sir");
	}

	@Override
	public void eat() {
		System.out.println("Eating");
		
	}

	@Override
	public void sleep() {
        System.out.println("Sleeping ");
		
	}
}

public class explm2_abstract {
	public static void main(String[] args) {
       Human kajalHuman = new Human();
       kajalHuman.sleep();
       
       //polymorphism
       
       Monkey m1=new Human();
     //  m1.speek();//can't initiated
       m1.Bite();
       
       BasicAnumal lovishAnumal = new Human();
       lovishAnumal.eat();
	}
}
