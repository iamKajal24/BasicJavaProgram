package DateAndTime;

public class DtNdTime {
	public static void main(String[] args) {
		// ager mei 1000 se divide karti hun to second
		// 3600 -> minute
		// 24->days
		// 365->1 year
		System.out.println(System.currentTimeMillis() / 1000 / 3600 / 24 / 365);
	}
}
