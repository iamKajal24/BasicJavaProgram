package DateAndTime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CompareDatesCompareDemo {
	public static void main(String[] args) throws ParseException {
		/*
		 * 1. Create simpleDate fromate obj with required date pattern 2. create two
		 * dates obj 3. call compare to method on date obj
		 */

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/mm/yyyy");
		Date date1 = simpleDateFormat.parse("04/11/2024");
		Date date2 = simpleDateFormat.parse("10/11/2024");

		if (date1.compareTo(date2) < 0) {
			System.out.println("Date1 is less Than Date2");
		} else if (date1.compareTo(date2) > 0) {
			System.out.println("Date1 is greater than Date2");
		} else if (date1.compareTo(date2) == 0) {
			System.out.println("Both dates are equals");
		} else {
			System.out.println("Error");
		}
	}
}
