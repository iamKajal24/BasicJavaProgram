package OOPs;

class employee {
	int id;
	String name;
    double salary;
    
	public int getid() {
		return id;
	}

	public String getname() {
		return name;
	}
	public double getsalary() {
		return salary;
	}

	public void setid(int id) {
		this.id= id;
	}

	public void setname(String name) {
		 this.name=name;
	}
	public void setsalary(double salary) {
		 this.salary=salary;
	}

	public void employeedetails() {
		System.out.println("Employee id  : " + this.getid());
		System.out.println("Employee name  : " + this.getname());
		System.out.println("Salary : " + this.getsalary());
	}

}

public class Classobj_Practice {
	public static void main(String[] args) {
		employee em = new employee();
		em.setid(567);
		em.setname("Miss Kajal  as a Java Developer");
		em.setsalary(8000000.00);
		
		employee em1 = new employee();
		em1.setid(786);
		em1.setname("Miss Kajal Pandit");
		em1.setsalary(1000000.00d);
		
		
		
	
		em.employeedetails();
		em1.employeedetails();
	}

}
