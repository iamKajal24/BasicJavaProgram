package OOPs;

class emplo {
	int id;
	String nameString;

	public emplo(int id, String nameString) {
		this.id = id;
		this.nameString = nameString;
	}

	public int getId() {
		return id;
	}

	public String getNameString() {
		return nameString;
	}
}

class manager extends emplo {

	String branchString;

	public manager(int id, String nameString, String branchString) {
		super(id, nameString);
		this.branchString = branchString;

	}

	public String getBranchString() {
		return branchString;
	}
}

public class this_super {

	public static void main(String[] args) {
		emplo emplo = new emplo(56, "kajal");
		System.out.println(emplo.getId());
		System.out.println(emplo.getNameString());

		manager m1 = new manager(67, " , Miss kajal Pandit", " , Java Developer");
		System.out.println(m1.getId() + " " + m1.getNameString() + " " + m1.branchString);
	}
}
