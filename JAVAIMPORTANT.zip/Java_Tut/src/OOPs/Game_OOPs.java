package OOPs;

public class Game_OOPs {
	public static void main(String[] args) {
		
		/*
		 create a clas Game, which edition allows a user to play "Guess the NUmber
		  game once . Game should have the following methods.
		  
		  1. Constructor to generate the random number
		  2. TakeUser input() to take a user input of number
		  3. isCorrectNumber() to detect whether the number enterd by  the user is true
		  4. getter and setter for noOfGuesses
		  Use properties such as noOfGuess(int), etc to get this task done
		 
		 */
	}

}
