package OOPs;

interface sampleInterface {
	void math1();

	void math2();

}

interface childSampleInterface extends sampleInterface {

	void math3();

	void math4();

}

class MySampleClass implements childSampleInterface {

	@Override
	public void math1() {
		System.out.println("math1");

	}

	@Override
	public void math2() {
		System.out.println("math2");

	}

	@Override
	public void math3() {
		System.out.println("math3");

	}

	@Override
	public void math4() {
		System.out.println("math4");

	}
}

public class Inheritance_In_Interface {
	public static void main(String[] args) {
		MySampleClass mSampleClass = new MySampleClass();
		mSampleClass.math1();
		mSampleClass.math2();
		mSampleClass.math3();
		mSampleClass.math4();
	}
}
