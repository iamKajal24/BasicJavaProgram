package OOPs;

class A {
	public int kajal() {
		return 5;
	}

	public void meth2() {
		System.out.println("i am method 2 of class A");
	}
}

class B extends A {

	@Override
	public void meth2() {
		System.out.println("i am method 2 of class B");
	}

	public void meth3() {
		System.out.println("I am method 3 of class B");
	}
}

public class Method_Overriding {
	public static void main(String[] args) {

		A a1 = new A();
		a1.meth2();

		B b1 = new B();
		b1.meth2();
		b1.meth3();

	}
}
