package OOPs;

interface camera2 {
	void takeSnap2();

	void recordVideo2();

	private void greet2() {
		System.out.println("Good Morning");
	}

	default void record4kVideo2() {
		greet2();
		System.out.println("Recording in 4K...");
	}
}

interface wifi2 {
	String[] getNetwork2();

	void connectToNetwork2(String networks);
}

class MyCellPhone2 {
	void callNumber2(int phoneNumber) {
		System.out.println("Calling " + phoneNumber);
	}

	void PickCall2() {
		System.out.println("Connecing..");
	}
}

class SmartPhone2 extends MyCellPhone2 implements wifi2, camera2 {
	public void takeSnap2() {
		System.out.println("Taking snap");
	}

	public void recordVideo2() {
		System.out.println("Playing video..");
	}

	@Override
	public String[] getNetwork2() {
		System.out.println("Getting List of Networks ");
		String[] networkList2 = { "Kajal", "Riya", "Khushi", "Priya" };
		return networkList2;
	}

	@Override
	public void connectToNetwork2(String networks2) {
		System.out.println("Connecting to " + networks2);

	}
}

public class Polymorphism {
	public static void main(String[] args) {
		camera2 cam = new SmartPhone2(); // this is a smartPhone but use it as a camera
		// cam.getNetwork2();---> Not allowed
		cam.record4kVideo2();
		
	    SmartPhone2 obj = new SmartPhone2();
	    obj.takeSnap2();
	    obj.record4kVideo2();
	    obj.getNetwork2();
	    //obj.connectToNetwork2();
	}
}
