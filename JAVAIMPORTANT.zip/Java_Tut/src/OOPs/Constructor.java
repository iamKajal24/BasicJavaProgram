package OOPs;

class MyEmployee1 {
	private int id;
	private String name;

	public MyEmployee1(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getid() {
		return id;
	}

	public String getname() {
		return name;
	}

	public void setid(int id) {
		this.id = id;
	}

	public void setname(String name) {
		this.name = name;
	}
	
	public void empDetaile() {
		System.out.println(" ID : " + this.getid());
		System.out.println("Name : " + this.getname());
	}
}

	public class Constructor {
		public static void main(String[] args) {

			MyEmployee1 obj = new MyEmployee1(45, "Miss Riya ");
			obj.empDetaile();
		}
	}


