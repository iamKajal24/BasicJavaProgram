package OOPs;

abstract public class MyClass {
	
	//complete method
	public void cal() {
		System.out.println("Calculating results");
	}
	
	//abstract method
	abstract public void launchRocket();
	
}
class Demo{
	public static void main(String[] args) {
		MyChild mChild = new MyChild();
		mChild.launchRocket();
	}
}