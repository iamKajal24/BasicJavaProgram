package OOPs;

class Base{
	int x;
	public int y;
	
	public int getx() {
		return x;
	}
	public void setx(int x) {
		System.out.println("i am in base setting x now");
		this.x=x;
	}
	public void Printme() {
		System.out.println("I am Constructor");
	}
}

class Derived extends Base{
	int y;
	
	public int getY() {
		return y;
	}

	public void setY(int y) {
		System.out.println("i am in Derived setting y now");
		this.y = y;
	}
}

public class Inheritance {	
	public static void main(String[] args) {
//		Base b1 = new Base();
		Derived b1 =new Derived();
		b1.setx(5);
		b1.setY(7);
		System.out.println(b1.getx());
		System.out.println(b1.getY());
		
	
	}
}
