package OOPs;

import java.util.Random;
import java.util.Scanner;

class Game{
	public int number;
	public int noOfGuesses;
	public int inputNumber;
	
	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getNoOfGuesses() {
		return noOfGuesses;
	}

	public void setNoOfGuesses(int noOfGuesses) {
		this.noOfGuesses = noOfGuesses;
	}
	
	 Game() {
		Random rand = new Random();
		this.number=rand.nextInt();
	}
	
	int takeUserInput() {
		System.out.println("Guess the number ");
		Scanner sc  = new Scanner(System.in);
		inputNumber = sc.nextInt();
		return inputNumber;
	}
	boolean isCorrectNumber() {
		if(inputNumber==number) {
			return true;
		}
		else if(inputNumber<number) {
			System.out.println("Too low...");
		}
		else if(inputNumber>number) {
			System.out.println("Too high...");
		}
		return false;
	}
}

public class Excercise_50 {
	public static void main(String[] args) {
		Game game = new Game();
		game.takeUserInput();
	    boolean b =	game.isCorrectNumber();
	    System.out.println(b);
	}

}
