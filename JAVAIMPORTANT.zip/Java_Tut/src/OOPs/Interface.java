package OOPs;

interface Bicycle {
	
	void applyBreak(int decrement);
	void speedUp(int increment);
	
}

class AvonCycle implements Bicycle {
	void blowHorn() {
		System.out.println("Pee Pee Poo Poo. tujhe dekha maine");
	}

	@Override
	public void applyBreak(int decrement) {
		// TODO Auto-generated method stub
		System.out.println("applying Break....");
	}

	@Override
	public void speedUp(int increment) {
		// TODO Auto-generated method stub
		System.out.println("Playing SpeedUp.....");
	}
}

public class Interface {
	public static void main(String[] args) {
		AvonCycle aCycle = new AvonCycle();
		aCycle.blowHorn();
		aCycle.applyBreak(0);
		aCycle.speedUp(0);

	}
}
