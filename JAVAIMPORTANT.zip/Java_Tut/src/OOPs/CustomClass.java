package OOPs;

class Employee1 {
	int id;
	String nameString;
	float salary;

	public void printDetails() {
		System.out.println("My Id is " + id);
		System.out.println("and My name is  " + nameString);
	}

	public int getsalary() {
		return (int) salary;
	}
}

public class CustomClass {

	public static void main(String[] args) {
		System.out.println("This is custom class ");
		Employee1 obj = new Employee1(); // instatiating a new employee obj
		Employee1 ria = new Employee1();
		Employee1 kajal = new Employee1();

		// setting Attributes
		obj.id = 98;
		obj.nameString = "Kajal";
		obj.salary = 76000.00f;

		ria.id = 87;
		ria.nameString = "Rahul";
		ria.salary = 55000.45f;

		// Printing Attributes
		obj.printDetails();
		int salary = obj.getsalary();
		System.out.println(salary);

		ria.printDetails();
		System.out.println(ria.getsalary());

//		System.out.println(obj.id);
//		System.out.println(obj.nameString);

	}

}
