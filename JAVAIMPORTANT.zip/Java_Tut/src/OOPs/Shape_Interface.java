package OOPs;

public interface Shape_Interface {
	public static final int i=34;
	
	public abstract void calArea(int r);

}

class Circle implements Shape_Interface{
	public void calArea(int r) {
		System.out.println("Area of Circle is " + (Math.PI*r*r));
	}
	
	public static void main(String[] args) {
		Shape_Interface s1 = new Circle();
		s1.calArea(2);
	}
}
