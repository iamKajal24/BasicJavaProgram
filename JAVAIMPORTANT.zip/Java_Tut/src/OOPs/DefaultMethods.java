package OOPs;

interface camera {
	void takeSnap();

	void recordVideo();

	private void greet() {
		System.out.println("Good Morning");
	}

	default void record4kVideo() {
		greet();
		System.out.println("Recording in 4K...");
	}
}

interface wifi {
	String[] getNetwork();

	void connectToNetwork(String networks);
}

class MyCellPhone {
	void callNumber(int phoneNumber) {
		System.out.println("Calling " + phoneNumber);
	}

	void PickCall() {
		System.out.println("Connecing..");
	}
}

class SmartPhone extends MyCellPhone implements wifi, camera {
	public void takeSnap() {
		System.out.println("Taking snap");
	}

	public void recordVideo() {
		System.out.println("Playing video..");
	}

	@Override
	public String[] getNetwork() {
		System.out.println("Getting List of Networks ");
		String[] networkList = { "Kajal", "Riya", "Khushi", "Priya" };
		return networkList;
	}

	@Override
	public void connectToNetwork(String networks) {
		System.out.println("Connecting to " + networks);

	}
}

public class DefaultMethods {
	public static void main(String[] args) {
		SmartPhone mSmartPhone = new SmartPhone();
		mSmartPhone.record4kVideo();

		String[] ar = mSmartPhone.getNetwork();
		for (String item : ar) {
			System.out.println(item);
		}
	}
}
