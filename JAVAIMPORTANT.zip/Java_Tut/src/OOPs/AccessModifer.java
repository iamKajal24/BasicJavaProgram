package OOPs;

class MyEmployee {
	private int id;
	private String name;

	public int getid() {
		return id;
	}

	public String getname() {
		return name;
	}

	public void setid(int id) {
		this.id = id;
	}

	public void setname(String name) {
		this.name = name;
	}

	public void employeedetails() {
		System.out.println("Employee id  : " + this.getid());
		System.out.println("Employee name  : " + this.getname());
	}
}

public class AccessModifer {
	public static void main(String[] args) {
		MyEmployee em = new MyEmployee();
		em.setid(786);
		em.setname("Miss Kajal");

		em.employeedetails();
	}
}
