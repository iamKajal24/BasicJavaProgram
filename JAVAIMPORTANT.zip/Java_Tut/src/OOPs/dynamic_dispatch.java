package OOPs;

class phone {

	public void showTime() {
		System.out.println("Time is 9 am");
	}

	public void on() {
		System.out.println("Turning on phone ");
	}
}

class smartphone extends phone {
	public void music() {
		System.out.println("Playing musing ");
	}

	public void on() {
		System.out.println("turning on smartPhone ");
	}
}

public class dynamic_dispatch {
	public static void main(String[] args) {
//		phone obj = new smartphone();
//		obj.showTime();
//		obj.on();

		smartphone sp = new smartphone();
		sp.music();

	}
}
