package OOPs;

 public class MyChild extends MyClass {
	 
	 @Override
	public void launchRocket() {
		System.out.println("MyChild Class is going to launch from NASA ");
		
	}
}