package OOPs;
class cell_phone{
	public void ringing() {
		System.out.println("Phone is ringing ");
	}
	public void vibration() {
		System.out.println("phone is vibrating");
	}
	public void cellFriend() {
		System.out.println("calling Amrita");
	}
	
}

public class Class_Problem2 {
	public static void main(String[] args) {
		cell_phone cell = new cell_phone();
		cell.ringing();
		cell.vibration();
		cell.cellFriend();
	}

}
