package OOPs;

class Animal {

	String color;
	String placeString;

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		System.out.println("Who is the animals ??");
		this.color = color;
	}

	public String getPlaceString() {
		return placeString;
	}

	public void setPlaceString(String placeString) {
		this.placeString = placeString;
	}
}

class Dog extends Animal {
	String dogNameString;

	public String getDogNameString() {
		return dogNameString;
	}

	public void setDogNameString(String dogNameString) {
		System.out.println("i am dogs at someswar gali ");
		this.dogNameString = dogNameString;
	}

}

class puppy extends Dog {
	String puppyname;

	public String getPuppyname() {
		return puppyname;
	}

	public void setPuppyname(String puppyname) {
		System.out.println("wow so cute lovely puppy !! , I lve you so much ");
		this.puppyname = puppyname;
	}

}

public class Animal_Inheritencee {
	public static void main(String[] args) {
//		Animal a1 = new Animal();
//        a1.setColor("Black");
//        a1.setPlaceString("Haridwar");
//        System.out.println(a1.getColor());
//        System.out.println(a1.getPlaceString());

//        Dog d1 = new Dog();
//        d1.setDogNameString("Rocky");
//        d1.setColor("Black");
//        d1.setPlaceString("Haridwar");
//        System.out.println(d1.getColor());
//        System.out.println(d1.getPlaceString());
//        System.out.println(d1.getDogNameString());

		puppy p1 = new puppy();
		p1.setColor("Grey");
		p1.setPlaceString("Haridwar");
		p1.setDogNameString("Rockey");
		p1.setPuppyname("Rockey Puppy's");
		System.out.println(p1.getColor());
		System.out.println(p1.getDogNameString());
		System.out.println(p1.getPlaceString());
		System.out.println(p1.getPuppyname());

	}
}
