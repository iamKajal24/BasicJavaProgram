package OOPs;

abstract class Parent{
	public Parent(){
		System.out.println("Mai base class ka construtor hun");
	}
	public void sayHello() {
		System.out.println("Hello");
	}
	abstract public void greet();
}

class child extends Parent{
	@Override
	public void greet() {
		System.out.println("Good morning");
	}
}

abstract class child3 extends Parent{
	public void th() {
		System.out.println("I am good");
	}
}
public class Abstract {
	public static void main(String[] args) {
		
		child c1 =  new child();
        c1.greet();
	}
}
