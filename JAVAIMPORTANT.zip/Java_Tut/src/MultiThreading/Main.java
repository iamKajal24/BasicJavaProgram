package MultiThreading;

public class Main {
	public static void main(String[] args) {
		company comp = new company();
		Producer producer = new Producer(comp);
		Consumer consumer = new Consumer(comp);
		producer.start();
		consumer.start();
	}
}
