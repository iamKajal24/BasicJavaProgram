package MultiThreading;

class MyThread1 extends Thread{
	public void run() {
		int i=0;
		while(i<4000) {
			System.out.println("My Cooking Thread is running");
			System.out.println("I am Happy");
		}
	}
}
class MyThread2 extends Thread{
	public void run() {
		int i=0;
		while(i<4000) {
			System.out.println("myThread for chatting with her");
			System.out.println("I am Sad");
		}
	}
	
}

public class program1 {
	public static void main(String[] args) {
		MyThread1 m1 = new MyThread1();
		MyThread2 m2 = new MyThread2();
		m1.start();
		m2.start();
	}

}
