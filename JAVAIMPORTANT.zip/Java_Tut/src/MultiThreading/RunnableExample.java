package MultiThreading;

class MyThreadRunnable1 implements Runnable {
	public void run() {
		System.out.println("I am thread1, not a threat.");
	}
}

class MyThreadRunnable2 implements Runnable {
	public void run() {
		System.out.println("I am thread2, not a threat.");
	}
}

public class RunnableExample {  // Renamed from Runnable to RunnableExample
	public static void main(String[] args) {
		MyThreadRunnable1 bullet1 = new MyThreadRunnable1();
		Thread t1 = new Thread(bullet1); 
		
		MyThreadRunnable2 bullet2 = new MyThreadRunnable2();
		Thread t2 = new Thread(bullet2);
		
		t1.start();
		t2.start();
	}
}
