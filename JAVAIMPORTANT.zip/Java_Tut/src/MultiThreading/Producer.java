package MultiThreading;

public class Producer extends Thread {

	company c;

	public Producer(company c) {
		this.c = c;
	}

	public void run() {
		int i = 1;
		while (i <= 10) {
			this.c.produce_item(i);
			i++;
			try {
				Thread.sleep(1000);
			} catch (Exception e) {

			}
		}
	}

}
