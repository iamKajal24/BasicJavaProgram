package MultiThreading;

class MyThread24 implements Runnable{

	@Override
	public void run() {
		//task for thread
		for(int i=1;i<=10;i++) {
			System.out.println("Value of i is : " + i);
			try {
				Thread.sleep(1000);
			}
			catch(Exception e) {
				System.out.println("error");
			}
		}
	}
}

public class UsingRunnable {
	public static void main(String[] args) {
		MyThread24 t1 = new MyThread24();
		Thread t11 = new Thread(t1);
		t11.start();
	}

}
