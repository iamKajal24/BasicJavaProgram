package MultiThreading;

class userThread extends Thread {
	public void run() {
		System.out.println("This is user defind thred");
	}
}

public class ThreadOp {
	public static void main(String[] args) {
		System.out.println("Program started");
		int x = 76 + 34;
		System.out.println("Sum is " + x);

		// Thread
		// get name of thread
		Thread t = Thread.currentThread();
		String tname = t.getName();

		// set name
		t.setName("MyMain");
		System.out.println("Current running thread is " + t.getName()); // write can tname

		try {
			Thread.sleep(2000);
		} catch (Exception e) {

		}

		// get Id

		System.out.println(t.getId());

		// going to StartDocument user defind thread

		System.out.println("Terminated..");

		userThread t1 = new userThread();
		t1.start();
	}
}
