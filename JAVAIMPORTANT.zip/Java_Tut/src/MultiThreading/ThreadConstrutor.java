package MultiThreading;

class MyThr  extends Thread{
	public MyThr(String name) {
		super(name);
	}
	public void run() {
		int i=20;
		System.out.println("Thankyou");
//		while(true) {
//			System.out.println("I am a Thread");
//		}
	}
}

public class ThreadConstrutor {
	public static void main(String[] args) {
		MyThr t1 = new MyThr("Kajal");
		System.out.println("The id of the therad t is : " + t1.getId());
	}

}
