package JavaBasic;

public class MethodOverloading {
	static void change(int a) {
		a = 98;
	}
	
	static void change2(int arr[]) {
		arr[1] = 98;
	}

	static void tellJoke() {
		System.out.println("I inveted a new Word!\n" + "Plagiarism!");
	}

	public static void main(String[] args) {
//		tellJoke();

		int marks[] = { 98, 34, 567, 67, 89 };

//	  case 1: changing the Integer
//		int x = 67;
//		change(x);
//		System.out.println(x);
		
//		  case 1: changing the Array
 /*         change2(marks);
          System.out.println("The value of x after running change is : " + marks[1]);
          
          */
		
		
	}
}
