package JavaBasic;

public class Literals {
	public static void main(String[] args) {
		Byte ageByte=50;
		char ch='A';
		int age=56;
		long agelong=87l;
		float f1 = 13.7f;
		double d=234.87d;
		boolean b=true;
		String aString="Kajal";
		
		System.out.println(ageByte);
	}

}
