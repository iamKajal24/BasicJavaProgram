package JavaBasic;

public class ArrayPractice {
	public static void main(String[] args) {
		/*
		 * // calculate their sum
		 * 
		 * float num[] = { 4.09f, 5.8f, 6.98f, 7.76f, 8.6f }; float sum = 0;
		 * 
		 * // 1 st approach
		 * 
		 * for (float i = 0; i < num.length; i++) { sum = sum + num[(int) i]; }
		 * System.out.println(sum);
		 * 
		 * // 2nd Approach
		 * 
		 * for (float element : num) { sum = sum + element; } System.out.println(sum);
		 */

		// program 2

	/*
	    float marks[] = { 4.09f, 5.8f, 6.98f, 7.76f, 8.6f };
		float num = 5.9f;
		boolean isInArray = false;
		for (float element : marks) {
			if (num == element) {
				isInArray = true;
				break;
			}
		}
		if (isInArray) {
			System.out.println("The value is present in the Array");
		} else {
			System.out.println("The value is not present in the Array");
		}
		*/

	}
}
