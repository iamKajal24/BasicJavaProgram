package JavaBasic;

import java.util.Arrays;

public class Array {
	public static void main(String[] args) {
	//	int[] marks = new int [5];
		
//		int[] marks;
//		marks=new int [5];
		
	/*
	 * marks[0]=100; 
	 * marks[1]=97; 
	 * marks[2]=80;
	 *  marks[3]=76;
	 *   marks[4]=110;
	 */
      
		int marks[]= {65,77,98,67,100};
		System.out.println(marks[3]);
		
	}

}
