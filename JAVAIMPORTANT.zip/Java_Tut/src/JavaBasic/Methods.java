package JavaBasic;

public class Methods {

//	1st approach

	static int logic(int x, int y) {
		int z;
		if (x > y) {
			z = x + y;
		} else {
			z = (x + y) * 5;
		}
		return z;
	}

//	2nd approach calling method

	/*
	 * int logic(int x,int y)
	 *  { 
	 *  int z; 
	 *  if(x>y)
	 *   {
	 *    z=x+y; 
	 *   } 
	 *   else {
	 *   
	 *    z=(x+y)*5; } 
	 *    return z; 
	 *    }
	 */

	public static void main(String[] args) {
		int x = 5;
		int y = 9;
		/*
		 * Methods obj = new Methods(); // Method invocation using obj creation int
		 * c=obj.logic(x, y);
		 */

		int c = logic(x, y);
		System.out.println(c);

	}
}
