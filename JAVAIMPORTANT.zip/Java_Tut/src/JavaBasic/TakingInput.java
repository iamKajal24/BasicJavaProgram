package JavaBasic;

import java.util.Scanner;

public class TakingInput {
	public static void main(String[] args) {
		System.out.println("Student DEtails :");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Roll No. ");
		int num = scanner.nextInt();
		System.out.println("Enter Student Name");
		String name = scanner.next();

		System.out.println("RollNo :" + num);
		System.out.println("Name : " + name);
	}
}
