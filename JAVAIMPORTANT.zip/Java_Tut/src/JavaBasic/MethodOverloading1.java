package JavaBasic;




public class MethodOverloading1 {
	
	static void foo() {
		System.out.println("Good morning bro");
	}
	
//	 int a -> this is prameter
	static void foo(int a) {
		System.out.println("Good Morning " + a + " bro");
	}
	static void foo(int a,int b) {
		System.out.println("Good morning " + a + " bro " + b + " sister");
	}
	public static void main(String[] args) {
		
//		method Overloding
		
		foo();
		foo(3000); // argument are actual!
		foo(3000, 4000);
		
		
	}

}
