package JavaBasic;

public class Loop {
	public static void main(String[] args) {
//		practice 1
		/*
		 * int n = 4;
		 *  for (int i = n; i > 0; i--) 
		 *  { for (int j = 0; j < i; j++) 
		 *  {
		 * System.out.print("*"); 
		 * }
		 * System.out.print("\n"); }
		 */	
		
//	problem 2  add even number
		
		/*
		 * int sum=0; int n=3; 
		 * for(int i=0;i<n;i++) 
		 * { sum=sum+(2*i); }
		 * System.out.println(sum);
		 */
	
//	Problem 3 Multiplication table
		
		/*
		 * int n=10; int mul=0; 
		 * for(int i=1;i<=10;i++) {
		 * System.out.printf("%d X %d = %d\n" , n,i,n*i); 
		 * }
		 */
		
//		problem 4 multiplication reverse order
		
		/*
		 * int n=10; int mul=0; 
		 * for(int i=10;i>=1;i--) {
		 * System.out.printf("%d X %d = %d\n" , n,i,n*i); }
		 */
		
//		repeat number using while loop fact program
		
		/*
		 * int n =3; int i=1; int fact=1; 
		 * while(i<=n) 
		 * { fact = fact*i; i++; }
		 * System.out.println(fact);
		 */
		
// add sum number
		
		int n=8;
		int sum=0;
		for(int i=1;i<=2;i++) {
			sum +=n*i;
		}
		System.out.println(sum);
			
		
	}
}
