package JavaBasic;

public class Opertaor {
	public static void main(String[] args) {
		int a=4;
	//	int b=6%a; // modulo operator
		 int b=9;
		  b +=3;
		System.out.println(a);
		System.out.println(b);
		
	}

}
