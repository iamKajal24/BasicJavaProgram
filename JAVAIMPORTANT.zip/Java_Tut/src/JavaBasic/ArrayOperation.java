package JavaBasic;

public class ArrayOperation {
	public static void main(String[] args) {	
		/*
		 * String[] nameStrings= {"kajal","kajal1","kajal2"};
		 * System.out.println(marks[1]);
		 */
		int marks[]= {65,77,98,67,100};
		System.out.println("length " + marks.length);
		
//		Display the array(Native way)
		
		/*
		 * System.out.println(marks[0]);
		 *  System.out.println(marks[1]);
		 * System.out.println(marks[2]);
		 *  System.out.println(marks[3]);
		 * System.out.println(marks[4]);
		 */
		
		// display the array (for loop)
		
		/*
		 * for(int i=0;i<marks.length;i++)
		 *  { System.out.println(marks[i]); }
		 */
		
		// display the array (for each loop)
		for(int element : marks) {
			System.out.println(element);
		}
		
		
	}

}
